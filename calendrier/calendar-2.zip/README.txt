A Pen created at CodePen.io. You can find this one at http://codepen.io/maggiben/pen/OPmLBW.

 A calendar that tells you how many events happened on a particular date